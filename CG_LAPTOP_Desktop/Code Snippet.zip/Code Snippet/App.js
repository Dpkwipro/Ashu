import "./styles.css";

import React, { useEffect } from "react";
export default function App() {
  const [dataList, setDataList] = React.useState([]);

  const remove = (id) => {
    let filteredArray = dataList.filter((item) => item.id !== id);
    //setDataList(filteredArray);
  };
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((result) => result.json())
      .then((data) => setDataList(data));
  }, []);

  return (
    <div>
      {dataList.map((data, key) => {
        return (
          <div className="container" key={key}>
            <button onclick={remove(data.id)}> X</button>
            <h4>{data.name}</h4>
            <p>
              {data.email} <br />
              {data.phone}
            </p>
          </div>
        );
      })}
    </div>
  );
}
